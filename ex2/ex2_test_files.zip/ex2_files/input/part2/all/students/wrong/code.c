#include <stdio.h>

int main() {
    int x, y, z;
    printf("Etner 3 numbers:\n");
    scanf("%d %d %d", &x, &y, &z);
    printf("the sum of the numbers is %d\n", x+y-z);
    return 0;
}